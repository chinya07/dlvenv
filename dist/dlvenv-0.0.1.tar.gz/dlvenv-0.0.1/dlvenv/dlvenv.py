def info():
    print("Welcome to Deep Learning Environment Module.")
    print("-------------------------------")
    print("Your Deep Learning Environment is Ready to use.")
    print("-------------------------------")